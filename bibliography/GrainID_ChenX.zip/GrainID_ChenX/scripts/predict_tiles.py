import argparse
import logging
import os

import numpy as np
import torch
import torch.nn.functional as Funct
from PIL import Image
from torchvision import transforms

# from unet import UNet
from scripts.Convs_Unet import UNet
from scripts.img_scale_trans import Scaling


def predict_img(model,
                full_img,
                device,
                scale_factor=1,
                out_threshold=0.5):
    model.eval()


    img_scale_trans = Scaling.preprocess(full_img, scale_factor)
    
    img = torch.from_numpy(img_scale_trans)   

    img = img.unsqueeze(0)
    img = img.to(device=device, dtype=torch.float32)

    with torch.no_grad():
        output = model(img)

        if model.n_classes > 1:
            probs = Funct.softmax(output, dim=1)
        else:
            probs = torch.sigmoid(output)

        probs = probs.squeeze(0)

        tf = transforms.Compose(
            [
                transforms.ToPILImage(),
                transforms.Resize(full_img.size[1]),
                transforms.ToTensor()
            ]
        )

        probs = tf(probs.cpu())
        full_mask = probs.squeeze().cpu().numpy()

    return full_mask > out_threshold


def mask_to_image(mask):
    return Image.fromarray((mask * 255).astype(np.uint8))


def predict_tiles(dir_model, tile_root, aug_list):
    
    '''
    output dirs will be 'aug_dirs' + '_pred'
    
    '''    

    scale = 0.5
    mask_threshold = 0.5
    
    for aug_name in aug_list:
        
        aug_dir = os.path.join(tile_root, aug_name)
        in_files = os.listdir(aug_dir) 
        out_dir = aug_dir + '_pred'
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)
 
        out_files = in_files
    
        model = UNet(n_channels=3, n_classes=1)
    
        logging.info("Loading model")
    
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        logging.info(f'Using device {device}')
        model.to(device=device)
        model.load_state_dict(torch.load(dir_model, map_location=device))
    
        logging.info("Model loaded !")
    
        for i, fn in enumerate(in_files):
            # logging.info("\nPredicting image {} ...".format(fn))
    
            img = Image.open(os.path.join(aug_dir, fn))
    
            mask = predict_img(model = model,
                               full_img = img,
                               scale_factor = scale,
                               out_threshold = mask_threshold,
                               device = device)
    

            out_fn = out_files[i]
            result = mask_to_image(mask)
            result.save(os.path.join(out_dir, out_fn))

            # logging.info("Mask saved to {}".format(out_files[i]))
    

