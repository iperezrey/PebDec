import os
import numpy as np

from PIL import Image, ImageFilter
import imgaug.augmenters as iaa



def topredict_filter_Mirror_Aug_overtiles(raw_folder,
                      fullimg_dir,
                      augfull_dir,
                      tiles_dir,
                      aug_list,
                      len_tile,
                      img_name):
    dirs = os.listdir(raw_folder)
    
    image_sizes_dict = {}
    
    for i in range(0 , len(dirs)):
        run_temp = dirs[i]
        image_train_raw0 = np.array(Image.open(os.path.join(raw_folder, run_temp, img_name)))
        #Filter
        # image_train_raw = np.array(image_train_raw0.filter(ImageFilter.DETAIL))     
        image_train_raw = iaa.SigmoidContrast(gain=6)(image = image_train_raw0)
        # image_train_raw = np.array(image_train_raw0.filter(ImageFilter.EDGE_ENHANCE))   
        # Usually
        # mask_train_raw = np.array(Image.open(os.path.join(raw_folder, run_temp, 'mask.png')))

        
        # Expand_overlaptile_Mirroring
        len_row_raw = len(image_train_raw[:,1,1])
        len_col_raw = len(image_train_raw[1,:,1])
        half_len = np.int(len_tile/4)
        image_to_train= expand_by_mirroring(image_train_raw, len_row_raw, len_col_raw, half_len)          
        save_full_raw(image_train_raw, run_temp, fullimg_dir) # Optional
        
        
        
        
        # Augumatation Six times
        
        for aug_name in aug_list:
            image_to_train_aug = augmt5_0325(image_to_train, aug_name)
            save_aug(image_to_train_aug, run_temp, augfull_dir, aug_name)  # Optional
            create_overlaptiles(image_to_train_aug, run_temp, aug_name, tiles_dir, len_tile)  # 可以在这里直接Predict
        
        size = [len_row_raw, len_col_raw]
            
        image_sizes_dict[run_temp] = size
        
    return image_sizes_dict
        
        
            

#%% expand and save
def expand_by_mirroring(image_train_raw,
                        len_row, 
                        len_col,
                        half_len):

    """ 
# For testing,
    1. expand left and up side by GLOBAL['len_Unet_tile']/4.
    2. expand right and button side by "residue + GLOBAL['len_Unet_tile']/4", where residue equals "GLOBAL['len_Unet_tile'] - len_row%GLOBAL['len_Unet_tile']"

"""
    len_img_tile = 4*half_len
    if len_row%len_img_tile == 0:
        row_expand = np.int(len_row + 0.5 * len_img_tile)
        col_expand = np.int(len_col + 0.5 * len_img_tile)        
    else:
        row_expand = np.int(len_row + 1.5 * len_img_tile - len_row%len_img_tile)
        col_expand = np.int(len_col + 1.5 * len_img_tile - len_col%len_img_tile)
    
    img_expand = np.uint8(np.zeros([row_expand, col_expand, 3]))

    

    if len_row%len_img_tile == 0:
        img_expand[half_len:half_len + len_row, half_len : half_len + len_col, :] = image_train_raw  
        img_expand[:half_len, :, :] = np.flipud(img_expand[half_len : 2 * half_len, :, :])
        img_expand[half_len + len_row:row_expand, :, :] = np.flipud(img_expand[half_len + len_row - half_len:half_len + len_row, :, :])
        img_expand[:, :half_len, :] = np.fliplr(img_expand[:, half_len :  2 * half_len, :])
        img_expand[:, half_len + len_col:col_expand, :] = np.fliplr(img_expand[:, half_len + len_col - half_len:half_len + len_col, :])    
         
    else:
        img_expand[half_len:half_len + len_row, half_len : half_len + len_col, :] = image_train_raw  
        img_expand[:half_len, :, :] = np.flipud(img_expand[half_len : 2 * half_len, :, :])
        img_expand[half_len + len_row:row_expand, :, :] = np.flipud(img_expand[half_len + len_row - (5 * half_len - len_row%len_img_tile):half_len + len_row, :, :])
        img_expand[:, :half_len, :] = np.fliplr(img_expand[:, half_len :  2 * half_len, :])
        img_expand[:, half_len + len_col:col_expand, :] = np.fliplr(img_expand[:, half_len + len_col - (5 * half_len - len_col%len_img_tile):half_len + len_col, :])    
        
    return img_expand



def save_full_raw(image_to_train, run_temp, fullimg_dir):
    img_full_folder = os.path.join(fullimg_dir, 'img')


    if not os.path.exists(img_full_folder):
        os.makedirs(img_full_folder)

   
    img_name = run_temp + '.jpg'

    
    img_path = os.path.join(img_full_folder, img_name)
    img_tosave = Image.fromarray(image_to_train)
    img_tosave.save(img_path)



#%% save_aug
def save_aug(image_to_train, run_temp, fullimg_dir, aug_name):
    img_full_folder = os.path.join(fullimg_dir, 'img')


    if not os.path.exists(img_full_folder):
        os.makedirs(img_full_folder)

   
    img_name = run_temp + '_' + aug_name + '.jpg'

    
    img_path = os.path.join(img_full_folder, img_name)
    img_tosave = Image.fromarray(image_to_train)
    img_tosave.save(img_path)


#%% aug_5
def augmt5_0325(img_expand,
                aug_method):

    aug_dict = {"rt00":rt00(img_expand),
                "rt90":rt90(img_expand),
                "rt180":rt180(img_expand),
                "fplr":fplr(img_expand), 
                "fpud":fpud(img_expand)}
    image = aug_dict[aug_method]    
    
    return image

def rt00(img):
    img_aug = img
    return img_aug

def rt90(img):
    img_aug = np.rot90(img)
    return img_aug

def rt180(img):
    img_aug = np.rot90(img, 2)
    return img_aug

def fplr(img):
    img_aug = iaa.Fliplr(1.0)(image = img)
    return img_aug

def fpud(img):
    img_aug = iaa.Flipud(1.0)(image = img)
    return img_aug



#%% create_tiles



def create_overlaptiles(img_temp, img_name, aug_name, tiles_folder, len_tile):

    """
    For overlaptile: the size of every tiles are 256, but the moving distance between tiles are 128;
    And only the valid prediction of central 128*128 images are used finally.
    
    """
    
    sample_length = np.int(len_tile/2)

    num_row = np.int8(len(img_temp[:,1,1]) / sample_length)-1
    num_col = np.int8(len(img_temp[1,:,1]) / sample_length)-1
    
    sample_folder_img = tiles_folder + "/" + aug_name + "/"
    if not os.path.exists(sample_folder_img):
        os.makedirs(sample_folder_img)
    
    for i in range(num_row):
        for j in range(num_col):

            sample_temp = img_temp[sample_length*i:sample_length*i + len_tile, sample_length*j : sample_length * j  + len_tile, :]
                
            if i + 1 < 10:
                num_r_str = '0' + str(i+1)
            else:
                num_r_str = str(i+1)
                
            if j + 1 < 10:
                num_c_str = '0' + str(j+1)
            else:
                num_c_str = str(j+1)
                

            write_dir_img = sample_folder_img + img_name + '_'  + num_r_str + '_' + num_c_str + '.jpg'
            
            img_tosave = Image.fromarray(sample_temp)
            img_tosave.save(write_dir_img)
                

#%% if __main__

if __name__ == "__main__":

    '''
readme:
    1. the names of folders in raw_folder are the site's name.
    2. Defaultly， the image and mask to train/test are named as 'img.jgp' and 'mask.png'.
    3.    
    
    '''

    raw_folder = './Flume'
    fullimg_dir = './Train_preparation/Full_totrain'
    augfull_dir = './Train_preparation/aug_totrain'
    tiles_dir = './Train_preparation/Tiles_0138/'
    
    predict_filter_Mirror_Aug_tiles(raw_folder,
                      fullimg_dir,
                      augfull_dir,
                      tiles_dir)
    