from skimage.morphology import thin
from PIL import Image
"""
This file is part of the accompanying code to our manuscript:

Chen, X., Hassan, M., Fu, X., "CNN for Image-based Sediment detection applied to a Large Terrestrial and Airborne Dataset".
submitted to Earth Surface Dynamics Discussions (2021)

"""

import numpy as np
import os 
import time

from scripts.predict_filter_mirror_aug_overtile import topredict_filter_Mirror_Aug_overtiles
from scripts.predict_tiles import predict_tiles
from scripts.combine_fractions import combine_fractions
from scripts.ensemble_vote_fill import ensemble_vote_fill
from scripts.vote_fill_thin_second import vote_fill_thin_second, border_thinning
import scripts.reverse as reverse


'''
[summary]
The scripts is for GrainID predicting.


***Important***
All tested images should be individually stored in a separate folder in './data/run_name/'

For example, './data/run_name/' contains   =>   '/image1_totest/img.jpg'
                                                '/image2_totest/img.jpg'
                                                '/image3_totest/img.jpg'
                                                '/image4_totest/img.jpg'
                                                ...

predictions will be stored in, './prediction/run_name/2-Final_Results/' 
                                            =>  '/image1_totest.png'
                                                '/image2_totest.png'
                                                '/image3_totest.png'
                                                '/image4_totest.png'
                                                ...

For reviewing purpose, the middle results ('augmentation, split, overlaptile, combination and vote') were stored. 
Although storing middle results would slow the processing speed, this version of GrainID is much efficient than current GrainSizing methods.

'''
#%% Directory Configuration for your own test
#####################################
# Directories to run
#####################################
run_name = 'example' 
img_name = 'img.jpg'
dir_raw = './data/' + run_name + '/'


# Dirs_prediction

prediction_mid = './prediction/' + run_name + '/1-Mid_Results' 
prediction_final = './prediction/' + run_name + '/2-Final_Results' 
fullimg_raw = './prediction/'  + run_name+ '/0-Full/Full_raw/'
dir_aug_full = './prediction/' + run_name + './0-Full/Full_aug/'


#%% Model parameters
GLOBAL = {
    ###############
    #Operation
    ###############
    'Stage_predicting' : True,
    'shift' : False,
    
    #########################################
    # Fix arguments
    #########################################
       
    # Dir_Model
    'dir_model': './Tiles_512_Sigmod6CT_ep150.pth',    
    #Aug_dirs
    'aug_list' : ['rt00', 'rt90', 'rt180', 'fplr', 'fpud'],
    # 'aug_list' : ['rt00', 'rt90', 'fpud'],
    #vote_filled_dir
    'vote_filled_dir' : '1 - voted_filled_full',
    # size of picture samples
    'len_img_samples-1' : 256,
    'len_img_samples-2' : 512,   
    
    #Vote : if vote = 2, then one a pixel will be considered as interstice once there are two (out of five) ensemble predictions shows negative value (interstice) in that pixel
    'vote_threshold' : 2,
    # Interstice thinning
    'thin_inters' : 2,
    'thin_inters_benchmark' : 2
}

def create_samples_aug_predict_combine_vote_fill():
    

    #%% 1 - Create Samples
    print("1 - preparing!!!")
    image_sizes_dict =  topredict_filter_Mirror_Aug_overtiles(dir_raw,
                                                              fullimg_raw,
                                                              dir_aug_full,
                                                              prediction_mid,
                                                              GLOBAL['aug_list'],
                                                              GLOBAL['len_img_samples-2'],
                                                              img_name)
    
    
    #%% 2 - Predicting
    print("2 - predicting!!!")
    predict_tiles(GLOBAL['dir_model'], prediction_mid, GLOBAL['aug_list'])
    
    
    #%% 3 - Combine Fraction
    print("3 - combining!!!")
    combine_fractions(prediction_mid, GLOBAL['aug_list'], GLOBAL['len_img_samples-2'], image_sizes_dict)
    

    #%% 4 - Vote
    '''
    If vote = 2 , it means if two prediction (five) shows there should be interstice, then mark it as edge.
    '''
    print("4 - voting&post-processing!!!")
    ensemble_vote_fill(prediction_mid, prediction_final, GLOBAL['aug_list'], GLOBAL['vote_threshold'])
    

        
if __name__ == '__main__':
      
    starttime = time.time()
    
    create_samples_aug_predict_combine_vote_fill()  
    
    endtime = time.time()
    print(starttime - endtime)
    
    